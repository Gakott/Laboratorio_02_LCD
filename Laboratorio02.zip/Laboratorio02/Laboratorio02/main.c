//********************************************************************************
//Universidad del Valle de Guatemala
//IE2023: Programacion de Microcontroladores
//Autor: Fernando Gabriel Caballeros Cu
//Proyecto: Laboratorio02.c
//Archivo: main.c
//Hardware: ATMega328P
//Created: 21/01/2026 19:41:30
//********************************************************************************

#define F_CPU 1000000UL
#include <avr/io.h>
#include <avr/interrupt.h>	
#include <util/delay.h>
#include <stdint.h>
#include <stdio.h>

//Librerias propias
#include "adc.h"
#include "lcd.h"
#include "uart.h"

//conversion de lectura del ADC a mV
static uint16_t adc_to_mv(uint16_t adc)
{
	return(uint32_t)adc *5000UL / 1023UL;
}

//De mv a V
static void format_voltage(char *buf, uint16_t mv)
{
	uint16_t v_int = mv / 1000;          // 0..5
	uint16_t v_dec = (mv % 1000) / 10;   // 2 decimales
	sprintf(buf, "%u.%02uV", v_int, v_dec);
}

static void clock_preescaler_1mhz (void)
{
	CLKPR = (1<<CLKPCE);
	CLKPR = (1<<CLKPS2);
}
int main(void)
{
	clock_preescaler_1mhz();
    lcd_init();
	adc_init();
	uart_init_9600_1mhz();
	sei();
	
	DDRC = ~(1<<PC0);
	PORTC = ~(1<<PC0);
	DIDR0 |= (1<<ADC0D);
	
	char vstr[8];
	char line[17];
	/*
	char line[17];
	const char *s1 = "0";
	*/
	while(1)
	{
		//leemos el primer potenciometro
		uint16_t adc0 = adc_read(0);
		uint16_t mv = adc_to_mv(adc0);
		//leemos el segundo potenciometro
		uint16_t adc1 = adc_read(1);
		
		format_voltage(vstr, mv);
		/*
		lcd_gotoxy(0,0);
		lcd_puts("S1: ");
		lcd_puts(vstr);
		lcd_puts("         ");
		*/
		//mostramos la informacion en la pantalla de ambos potenciometros
		lcd_gotoxy(0,0);
		snprintf(line, sizeof(line),"S1:%s S2:%4u", vstr, (unsigned)adc1);
		lcd_puts(line);
		//s3
		lcd_gotoxy(0,1);
		snprintf(line, sizeof(line), "S3:%4d", (int)s3);
		lcd_puts(line);

		_delay_ms(200);
	}
}

