/*
 * lcd.c
 *
 * Created: 21/01/2026 19:56:41
 *  Author: Usuario Dell
 */ 
#define F_CPU 1000000UL
#include "lcd.h"
#include <avr/io.h>
#include <util/delay.h>

// ======= MAPEO LCD =======
#define LCD_DATA_DDR_D   DDRD
#define LCD_DATA_PORT_D  PORTD
#define LCD_DATA_MASK_D  0b11111100   

#define LCD_DATA_DDR_B   DDRB
#define LCD_DATA_PORT_B  PORTB
#define LCD_DATA_MASK_B  0b00000011  

// Control: RS=PB2, E=PB3
// RW a GND
#define LCD_RS_DDR   DDRB
#define LCD_RS_PORT  PORTB
#define LCD_RS_BIT   PB2

#define LCD_E_DDR    DDRB
#define LCD_E_PORT   PORTB
#define LCD_E_BIT    PB3

static void lcd_pulse_enable(void)
{
	LCD_E_PORT |= (1 << LCD_E_BIT);
	_delay_us(1);
	LCD_E_PORT &= ~(1 << LCD_E_BIT);
	_delay_us(50);
}

static void lcd_write8(uint8_t val)
{
	// val[0..5] -> PD2..PD7
	uint8_t d_out = (val << 2) & LCD_DATA_MASK_D;
	LCD_DATA_PORT_D = (LCD_DATA_PORT_D & ~LCD_DATA_MASK_D) | d_out;

	// val[6..7] -> PB0..PB1
	uint8_t b_out = (val >> 6) & LCD_DATA_MASK_B;
	LCD_DATA_PORT_B = (LCD_DATA_PORT_B & ~LCD_DATA_MASK_B) | b_out;

	lcd_pulse_enable();
}

void lcd_cmd(uint8_t cmd)
{
	LCD_RS_PORT &= ~(1 << LCD_RS_BIT); // RS=0 comando
	lcd_write8(cmd);

	if (cmd == 0x01 || cmd == 0x02) _delay_ms(2); // clear/home
}

void lcd_putc(char c)
{
	LCD_RS_PORT |= (1 << LCD_RS_BIT); // RS=1 dato
	lcd_write8((uint8_t)c);
}

void lcd_puts(const char *s)
{
	while (*s) lcd_putc(*s++);
}

void lcd_gotoxy(uint8_t x, uint8_t y)
{
	// 16x2 t�pico: fila0=0x00, fila1=0x40
	uint8_t addr = (y == 0) ? 0x00 : 0x40;
	lcd_cmd(0x80 | (addr + x));
}

void lcd_clear(void)
{
	lcd_cmd(0x01);
}

void lcd_init(void)
{
	// Configurar pines como salida
	LCD_DATA_DDR_D |= LCD_DATA_MASK_D;
	LCD_DATA_DDR_B |= LCD_DATA_MASK_B;
	LCD_RS_DDR     |= (1 << LCD_RS_BIT);
	LCD_E_DDR      |= (1 << LCD_E_BIT);

	_delay_ms(20);

	// Secuencia est�ndar 8-bit
	LCD_RS_PORT &= ~(1 << LCD_RS_BIT);
	lcd_write8(0x30); _delay_ms(5);
	lcd_write8(0x30); _delay_us(150);
	lcd_write8(0x30);

	lcd_cmd(0x38); // 8-bit, 2 l�neas, 5x8
	lcd_cmd(0x0C); // display on, cursor off
	lcd_cmd(0x06); // entry mode
	lcd_clear();
}
