/*
 * uart.h
 *
 * Created: 25/01/2026 23:48:32
 *  Author: Usuario Dell
 */ 


#ifndef UART_H_
#define UART_H_

#include <stdint.h>

void uart_init_9600_1mhz(void);

extern volatile int16_t s3;
#endif /* UART_H_ */