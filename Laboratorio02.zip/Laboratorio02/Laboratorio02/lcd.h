/*
 * lcd.h
 *
 * Created: 21/01/2026 19:45:14
 *  Author: Usuario Dell
 */ 


#ifndef LCD_H_
#define LCD_H_

#include <stdint.h>

void lcd_init(void);
void lcd_cmd(uint8_t cmd);
void lcd_putc(char c);
void lcd_puts(const char *s);
void lcd_gotoxy(uint8_t x, uint8_t y);
void lcd_clear(void);

#endif