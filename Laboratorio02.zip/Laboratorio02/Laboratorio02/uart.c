/*
 * uart.c
 *
 * Created: 25/01/2026 23:49:08
 *  Author: Usuario Dell
 */ 
#define F_CPU 1000000UL
#include "uart.h"
#include <avr/io.h>
#include <avr/interrupt.h>

volatile int16_t s3 = 0;

void uart_init_9600_1mhz(void)
{
	// Double speed
	UCSR0A = (1<<U2X0);

	// UBRR = F_CPU/(8*BAUD) - 1 = 1,000,000/(8*9600) - 1 ? 12.02 -> 12
	UBRR0H = 0;
	UBRR0L = 12;

	// 8N1
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);

	// RX, TX y RX interrupt
	UCSR0B = (1<<RXEN0) | (1<<TXEN0) | (1<<RXCIE0);
}

ISR(USART_RX_vect)
{
	uint8_t c = UDR0;   // leer limpia la bandera

	if (c == '+') {
		if (s3 < 9999) s3++;   // l�mite opcional
	}
	else if (c == '-') {
		if (s3 > 0) s3--;      // evita irse a negativo
	}
	// cualquier otro caracter: ignorar
}
