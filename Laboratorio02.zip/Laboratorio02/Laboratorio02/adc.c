/*
 * adc.c
 *
 * Created: 22/01/2026 20:07:28
 *  Author: Usuario Dell
 */ 
#include "adc.h"
#include <avr/io.h>

void adc_init(void)
{
	ADMUX = (1 << REFS0);

	// ADC enable, prescaler = 8  (1MHz/8 = 125kHz )
	ADCSRA = (1 << ADEN) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t adc_read(uint8_t channel)
{
	channel &= 0x07;

	// Mantener REFS0 y ajustar canal
	ADMUX = (ADMUX & 0xF8) | channel;

	// Start conversion
	ADCSRA |= (1 << ADSC);

	// Esperar fin
	while (ADCSRA & (1 << ADSC)) {}

	return ADC; // 10-bit
}